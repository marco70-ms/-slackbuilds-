#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

typedef struct Foo_____u8 {
  uint8_t *a;
} Foo_____u8;

typedef struct Foo_____u8 Boo;

void root(Boo x);
