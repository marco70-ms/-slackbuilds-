#ifndef INCLUDE_GUARD_H
#define INCLUDE_GUARD_H

extern "C" {

void root();

} // extern "C"

#endif // INCLUDE_GUARD_H
