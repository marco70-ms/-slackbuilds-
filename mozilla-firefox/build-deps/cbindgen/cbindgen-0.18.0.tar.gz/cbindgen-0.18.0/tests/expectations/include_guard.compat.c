#ifndef INCLUDE_GUARD_H
#define INCLUDE_GUARD_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

void root(void);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif /* INCLUDE_GUARD_H */
