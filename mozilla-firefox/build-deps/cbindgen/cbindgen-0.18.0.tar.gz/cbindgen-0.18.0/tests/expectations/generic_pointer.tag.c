#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

struct Foo_____u8 {
  uint8_t *a;
};

typedef struct Foo_____u8 Boo;

void root(Boo x);
